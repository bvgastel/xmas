module Main (main) where
import InvToInv (main)