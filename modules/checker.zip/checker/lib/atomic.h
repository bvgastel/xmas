/*
 *  atomic.h
 *  SpeedHTTPd
 *
 *  Created by Bernard van Gastel on 29-04-10.
 *  Copyright 2010 Bit Powder. All rights reserved.
 *
 */
#ifndef _ATOMIC_H_
#define _ATOMIC_H_

#include <atomic>

#endif
