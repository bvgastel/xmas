/*
 *  stack.h
 *  SpeedHTTPd
 *
 *  Created by Bernard van Gastel on 08-05-10.
 *  Copyright 2010 Bit Powder. All rights reserved.
 *
 */
#ifndef _STACK_H_
#define _STACK_H_

#include "common.h"
#include "exception.h"
#include "assert.h"
#include "iterators.h"

namespace bitpowder {
namespace lib {

template <class T, class PtrContainer, T PtrContainer::*ptr> class Queue;

template <class T, class PtrContainer = typename std::remove_pointer<T>::type, T PtrContainer::*ptr = &PtrContainer::next>
class Stack {
public:
    typedef typename std::remove_pointer<T>::type X;
    typedef Stack Container;
private:
    mutable T value;
    NO_COPY(Stack);
public:
    inline Stack(T start = nullptr) :
        value(start) {
    }
    inline ~Stack() {
        clear();
    }
    inline Stack(Stack &&c) : value(nullptr) {
        std::swap(value, c.value);
    }

    void clear() {
        value = nullptr;
    }

    inline void push_back(T e) {
        if (e) {
            assert(e->*ptr == nullptr);
            e->*ptr = value;
            value = e;
        }
    }

    inline bool splice(Stack &c) {
        if (&c == this || c.empty())
            return false;
        if (!empty()) {
            T last = c.value;
            while (last && last->*ptr) {
                last = last->*ptr;
            }
            if (last)
                last->*ptr = value;
        }
        value = c.value;
        c.value = nullptr;
        return true;
    }

    inline bool splice(Queue<T, PtrContainer, ptr> &q) {
        if (q.empty())
            return false;
        q.tail->*ptr = value;
        value = q.head;
        q.head = q.tail = nullptr;
        return true;
    }

    inline T pop_back() {
        T e = std::move(value);
        if (e)
            value = std::move((T)e->*ptr);
        return e;
    }

    inline Stack getAll() {
        Stack retval;
        std::swap(retval.value, value);
        return retval;
    }

    inline T back() const {
        return value;
    }

    template <class P>
    inline int erase_if(P &&func) {
        int retval = 0;
        for (auto it = select(std::ref(func)).begin(); it != end(); it.erase(), ++retval);
        return retval;
    }

    template <class P>
    inline T first(P &&func) const {
        for (auto e : select(std::ref(func)))
            return e;
        return nullptr;
    }

    inline bool empty() const {
        return !value;
    }

    class const_iterator {
    protected:
        T *value;
    public:
        const_iterator(T *value) : value(value) {
        }
        const_iterator(const const_iterator &a) : value(a.value) {
        }
        const_iterator(const_iterator &&a) : value(nullptr) {
            std::swap(a.value, value);
        }
        ~const_iterator() {
        }
        inline T operator*() {
            return *value;
        }
        inline T operator->() {
            return *value;
        }
        inline void operator++() {
            value = value && *value ? &((*value)->*ptr) : nullptr;
        }
        inline const_iterator operator+(int i) {
            const_iterator retval = *this;
            while (retval && i-- > 0)
                ++retval;
            return retval;
        }
        inline bool operator!=(const const_iterator& b) {
            return !(*this == b);
        }
        inline bool operator==(const const_iterator& b) {
            if (value == b.value)
                return true;
            X *thisPointsTo = value && *value ? &**value : nullptr;
            X *bPointsTo = b.value && *b.value ? &**b.value : nullptr;
            return thisPointsTo == bPointsTo;
        }
        inline operator bool() {
            return value && *value;
        }
    };

    class iterator : public const_iterator {
    public:
        iterator(T *value) : const_iterator(value) {
        }
        iterator(const_iterator &&value) : const_iterator(std::move(value)) {
        }
        inline T erase() {
            T retval = std::move(*this->value);
            *this->value = std::move(bool(retval) ? retval->*ptr : nullptr);
            return retval;
        }
        inline void insert(const T & a) {
            if (!this->value || !*this->value)
                return;
            a->*ptr = std::move(*this->value);
            *this->value = a;
        }
        inline iterator operator+(int i) {
            return {const_iterator::operator+(i)};
        }
    };


    inline iterator begin() {
        return {&value};
    }
    inline iterator end() {
        return {nullptr};
    }

    inline const_iterator begin() const {
        return {&value};
    }
    inline const_iterator end() const {
        return {nullptr};
    }

    // suggested usage: std::ref(arg)
    template <class P>
    inline select_container<T, const Container, P> select(P&& func) const {
        return {*this, std::forward<P>(func)};
    }
    // suggested usage: std::ref(arg)
    template <class P>
    inline select_container<T, Container, P> select(P&& func) {
        return {*this, std::forward<P>(func)};
    }
    // suggested usage: std::ref(arg)
    template <class Ptr, class P>
    inline select_container<Ptr, const Container, P> selectTo(P&& func) const {
        return {*this, std::forward<P>(func)};
    }
    // suggested usage: std::ref(arg)
    template <class Ptr, class P>
    inline select_container<Ptr, Container, P> selectTo(P&& func) {
        return {*this, std::forward<P>(func)};
    }

    template <class P>
    inline auto sbegin(P &&func) const -> select_iterator<T,P,decltype(this->begin())> {
        return {begin(), std::forward<P>(func)};
    }
    template <class P>
    inline auto sbegin(P &&func) -> select_iterator<T,P,decltype(this->begin())> {
        return {begin(), std::forward<P>(func)};
    }
};

}
}

namespace std {

template <class T, class PtrContainer, T PtrContainer::*nextPtr>
void swap(bitpowder::lib::Stack<T, PtrContainer, nextPtr>& lhs, bitpowder::lib::Stack<T, PtrContainer, nextPtr>& rhs) {
    std::swap(lhs.value, rhs.value);
}

}
#endif


