/*
 *  simpleparse.cpp
 *  SpeedHTTPd
 *
 *  Created by Bernard van Gastel on 22-07-13.
 *  Copyright 2013 Bit Powder. All rights reserved.
 *
 */
#include "stringparse.h"

namespace bitpowder {
namespace lib {

}
}
