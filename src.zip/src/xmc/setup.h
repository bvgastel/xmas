#ifndef SETUP_H
#define SETUP_H


// TODO: can we insert version from qmake or a version file?
static const QString applicationName = "XMas Control Program";
static const QString applicationVersion = "0.1";
static const QString applicationDescr = "A control program for XMas Design and Verification tools.";

#endif // SETUP_H

